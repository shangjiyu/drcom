/*
	libdrcom - Library for communicating with DrCOM 2133 Broadband Access Server
	Copyright (C) 2005 William Poetra Yoga Hadisoeseno <williampoetra@yahoo.com>

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA	02111-1307	USA
*/

#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <pthread.h>

#include "md5.h"

#include "drcomd.h"
#include "daemon_server.h"
#include "client_daemon.h"
#include "log.h"

static void _build_login_packet(struct drcom_login_packet *login_packet, 
			struct drcom_info *info, struct drcom_host *host, 
			struct drcom_challenge *challenge)
{
	char s[25];
	unsigned char t[22], d[16];
	int i, passwd_len;
	/*u_int8_t fixedZero2[40] = {0x61,0x35,0x36,0x33,0x63,0x37,0x65,0x37,0x65,0x34,
				0x37,0x36,0x65,0x31,0x39,0x36,0x38,0x38,0x30,0x31,
				0x38,0x64,0x65,0x30,0x65,0x30,0x62,0x33,0x62,0x34,
				0x66,0x39,0x37,0x30,0x61,0x64,0x31,0x65,0x62,0x66};*/

	/* header */
	login_packet->host_header.pkt_type = PKT_LOGIN;
	login_packet->host_header.zero1 = 0x00;
	/*login_packet->host_header.zero2 = 0x00;*/
	login_packet->host_header.zero2 = strlen(info->username) +
			sizeof(struct drcom_host_header);
	memset(t, 0, 22);
	memcpy(t, &login_packet->host_header.pkt_type, 2);
	memcpy(t + 2, &challenge->challenge, 4);
	passwd_len = strlen(info->password);
	strncpy((char *) (t + 6), info->password, 16);
	/*first checksum*/
	MD5((unsigned char *) t, passwd_len + 6, d);
	memcpy(login_packet->host_header.checksum, d, 16);

	/* username */
	memset(login_packet->username, 0, 36);
	strncpy(login_packet->username, info->username, 36);

	/* unknown, maybe just a signature? */
	login_packet->net = 0x20; /*internet or intranet : fixed*/

	/* mac */
	login_packet->mac_code = 0x01; /*此位最好不要修改，会绑定MAC地址*/
	memcpy(login_packet->mac_xor, info->mac, 6);
	for (i = 0; i < 6; ++i)
		login_packet->mac_xor[i] ^= login_packet->host_header.checksum[i];

	/* ok, second checksum */
	/* l already calculated */
	/* l = strlen(info->password); */
	s[0] = 0x01;
	memcpy(s + 1, info->password, passwd_len);
	memcpy(s + 1 + passwd_len, &challenge->challenge, 4);
	memset(s + 1 + passwd_len + 4, 0, 4);
	MD5((unsigned char *) s, 1 + passwd_len + 4 + 4, d);
	memcpy(login_packet->checksum1, d, 16);

	/* nic */
	login_packet->num_nic = 0x01;
	memcpy(login_packet->nic,&info->hostip,4);
	memset(login_packet->nic+1, 0, 12);

	/* third checksum */
	login_packet->checksum2_half[0] = 0x14;
	login_packet->checksum2_half[1] = 0x00;
	login_packet->checksum2_half[2] = 0x07;
	login_packet->checksum2_half[3] = 0x0b;
	MD5((unsigned char *) login_packet, 0x65, d);
	memcpy(login_packet->checksum2_half, d, 8);

	/* we've got a dog */
	login_packet->dog = 0x01;

	/* host info */
	memset(login_packet->zero1, 0, 4);
	memcpy(&login_packet->host_info, host, sizeof(struct drcom_host));
	memset(login_packet->zero2, 0, 96);

	/* wtf? */
	login_packet->unknown1 = 0x09;
	login_packet->unknown2 = 0x00;
	login_packet->unknown3[0] = 0x02;
	login_packet->unknown3[1] = 0x0c;

	/* maybe we should use something random instead? */

	memcpy(login_packet->unknown4, d+10, 4);

	/*login_packet->unknown4[0] = 0x00;*/
	/*login_packet->unknown4[1] = 0xf0;*/
	/*login_packet->unknown4[2] = 0x66;*/
	/*login_packet->unknown4[3] = 0x33;*/
	login_packet->unknown4[4] = 0x00;
	login_packet->unknown4[5] = 0x00;

	/*login MAC*/
	memcpy(login_packet->unknown4+6,info->mac,6);
	/*login_packet->unknown4[6] = 0x00;
	login_packet->unknown4[7] = 0x16;
	login_packet->unknown4[8] = 0xea;
	login_packet->unknown4[9] = 0xb9;
	login_packet->unknown4[10] = 0x6f;
	login_packet->unknown4[11] = 0x50;*/
	login_packet->unknown4[12] = 0x00;
	login_packet->unknown4[13] = 0x00;
	login_packet->unknown4[14] = 0xf9;
	login_packet->unknown4[15] = 0xf7;
/*
	memcpy(login_packet->unknown4, d + 8, 8);
*/

	return;
}

static inline void _build_authentication(struct drcom_auth *auth, struct drcom_acknowledgement *acknowledgement)
{
	memcpy(auth, &acknowledgement->auth_info, sizeof(struct drcom_auth));
}

static void _build_keepalive(struct drcom_host_msg *keepalive, struct drcom_login_packet *login_packet, struct drcom_acknowledgement *acknowledgement)
{
	keepalive->msgtype = 0xff;
	memset(keepalive->msg, 0, 19);
	memcpy(keepalive->msg, login_packet->host_header.checksum, 16);
	memcpy(&keepalive->auth_info, &acknowledgement->auth_info, sizeof(struct drcom_auth));
	/*time_t _time_info = (time(NULL) % 86400);
	u_int8_t time1 = ((u_int8_t)(_time_info & 0xff));
	u_int8_t time2 = ((u_int8_t)(_time_info >> 8 & 0xff));
	memcpy(keepalive->time_info,&time1,1);
	memcpy(keepalive->time_info+1,&time2,1);*/
	memset(keepalive->time_info, 0, 2);
	/*there is no more need another 4 bytes*/
	memset(keepalive->zero,0,4);
	return;
}

static void add_except_address(struct drcom_handle *h, unsigned char *pkt, int pkt_size)
{
	struct drcom_acknowledgement *ack = (struct drcom_acknowledgement *)pkt;
	struct except_tuple *tuple = ack->tuple;
	
	while ((unsigned char *)tuple + sizeof(struct except_tuple) <= pkt + pkt_size) {
		if (tuple->addr == 0)
			return;

		if (tuple->flag == 1 || tuple->flag == 0) {
			add_except(h->conf, tuple->addr, tuple->mask);
			if (tuple->flag == 1)
				return;
		}

		tuple++;
	}
}

static int drcom_login(int s2, struct drcom_handle *h, int timeout)
{
	struct drcom_socks *socks = (struct drcom_socks *) h->socks;
	struct drcom_info *info = (struct drcom_info *) h->info;
	struct drcom_host *host = (struct drcom_host *) h->host;
	struct drcom_host_msg *response = (struct drcom_host_msg *) h->response;
	struct drcom_host_msg *keepalive = (struct drcom_host_msg *) h->keepalive;
	struct drcom_auth *auth = (struct drcom_auth *) h->auth;
	struct drcom_challenge *challenge;
	struct drcom_login_packet login_packet;
	struct drcom_acknowledgement *acknowledgement;
	int retry=0;
	unsigned char *pkt;
	int pkt_size;
	int ret;

	(void)timeout;

try_it_again_1:
	retry++;
	if(retry>3)
		return -1;
	if(_send_dialog_packet(socks, NULL, PKT_REQUEST)<0){
		report_daemon_msg(s2, "_send_dialog_packet(PKT_REQUEST) failed\n");
		return -1;
	}

	ret = _recv_dialog_packet(socks, &pkt, &pkt_size);
	if (ret < 0 || pkt_size < sizeof(struct drcom_challenge)) {
		if (pkt)
			free(pkt);
		report_daemon_msg(s2, "_recv_dialog_packet(PKT_CHALLENGE) failed\n");
		goto try_it_again_1;
	}
	
	challenge = (struct drcom_challenge *)pkt;
	if (challenge->serv_header.pkt_type != PKT_CHALLENGE) {
		free(pkt);
		report_daemon_msg(s2, "_recv_dialog_packet(PKT_CHALLENGE) returned non-challenge pkt\n");
		goto try_it_again_1;
	}

	/* Now the _real_ ip address of the server is known */
	info->servip = socks->servaddr_in.sin_addr.s_addr;

	_build_login_packet(&login_packet, info, host, challenge);

	free(pkt);

	retry=0;
try_it_again_2:
	retry++;
	if(retry>3)
		return -1;
	if(_send_dialog_packet(socks, &login_packet, PKT_LOGIN)<0){
		report_daemon_msg(s2, "_send_dialog_packet(PKT_LOGIN) failed\n");
		return -1;
	}

	ret = _recv_dialog_packet(socks, &pkt, &pkt_size);

	report_daemon_msg(s2, "received server ACK(pkt_size=%d)\n", pkt_size);

	if (ret < 0) {
		if (pkt)
			free(pkt);
		report_daemon_msg(s2, "_recv_dialog_packet(PKT_ACK_SUCCESS) failed\n");
		goto try_it_again_2;
	}

	acknowledgement = (struct drcom_acknowledgement *)pkt;
	if (acknowledgement->serv_header.pkt_type != PKT_ACK_SUCCESS) {
		free(pkt);
		report_daemon_msg(s2, "Server acknowledged failure\n");
		return -1;
	}

	add_except_address(h, pkt, pkt_size);
	_build_authentication(auth, acknowledgement);
	_build_keepalive(keepalive, &login_packet, acknowledgement);
	memcpy(response, keepalive, sizeof(*keepalive));
	report_daemon_msg(s2, "Login Succeeded\n");
	report_daemon_msg(s2, "You have used %u Minutes, and %uK bytes\n", 
		acknowledgement->time_usage, acknowledgement->vol_usage);

	free(pkt);

	return 0;
}

static void recv_initial_server_msg(struct drcom_handle *h)
{
	(void)h;
}

void do_command_login(int s2, struct drcom_handle *h)
{
	struct drcomcd_login cd_login;
	int r;

	r = safe_recv(s2, &cd_login, sizeof(struct drcomcd_login));
	if (r != sizeof(struct drcomcd_login)) {
		logerr("daemon: recv: %s", strerror(errno));
		return;
	}

	if(status != STATUS_IDLE){
		report_daemon_msg(s2, "Error, Already logged in\n");
		report_final_result(s2, h, DRCOMCD_FAILURE);
		return;
	}

	status = STATUS_BUSY;
	r = server_sock_init(h);
	if(r!=0){
		status = STATUS_IDLE;
		report_daemon_msg(s2, "Cannot create socket to server\n");
		report_final_result(s2, h, DRCOMCD_FAILURE);
		return;
	}

	r = drcom_login(s2, h, cd_login.timeout);
	if(r != 0){
		status = STATUS_IDLE;
		server_sock_destroy(h);
		report_daemon_msg(s2, "Login failed\n");
		report_final_result(s2, h, DRCOMCD_FAILURE);
		return;
	}

	status = STATUS_LOGGED_IN;

	recv_initial_server_msg(h);

	module_start_auth(h);

	pthread_create(&th_watchport,NULL,daemon_watchport, h);
	pthread_create(&th_keepalive,NULL,daemon_keepalive, h);

	report_final_result(s2, h, DRCOMCD_SUCCESS);
}


